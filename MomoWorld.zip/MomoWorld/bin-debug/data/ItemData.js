//物品类，用于存放所有物品信息。如：武器，消耗品，掉落品
var getItem = function (name) {
    if (name == "thing1")
        return thing1;
};
var thing1 = {
    name: "thing1"
};
